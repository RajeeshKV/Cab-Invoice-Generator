/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.wipro.userexceptions;

/**
 *
 * @author RajeeshKV
 */
public class NegativeKilometerException extends Exception{

    public NegativeKilometerException(String message) {
        super(message);
        System.out.println(message);
    }
    
    
    
}
