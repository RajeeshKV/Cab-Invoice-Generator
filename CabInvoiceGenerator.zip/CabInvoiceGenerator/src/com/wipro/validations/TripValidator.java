/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.wipro.validations;
import com.wipro.bean.CabBean;
import com.wipro.userexceptions.NegativeKilometerException;
import java.util.Random;
/**
 *
 * @author RajeeshKV
 */
public class TripValidator {
    static int[] res = new int[2];
    
    public static String printBillAmount(CabBean cabbean) {
        if(!(cabbean.getBookingID().substring(0,2).equalsIgnoreCase("AD"))  || !cabbean.getBookingID().substring(2, 7).replaceAll("[^a-zA-Z]", "").equals("")){
            System.out.println("Invalid booking ID ");
        }
        else if(cabbean.getUserID() < 1001 || cabbean.getUserID() > 1500){
            System.out.println("Invalid user ID");
        }
        else if(!cabbean.getCabType().equalsIgnoreCase("Tata Indica") && !cabbean.getCabType().equalsIgnoreCase("Tata indigo") && !cabbean.getCabType().equalsIgnoreCase("BMW") && !cabbean.getCabType().equalsIgnoreCase("Logan")){
            System.out.println("Invalid cab type");
        }
        else if(Integer.parseInt(cabbean.getKmsUsed()) < 0){
            try{
            throw new NegativeKilometerException("NegativeKilometerException found");
            }
            catch(NegativeKilometerException e){
                System.out.println(e);
            }
        }
        else{
            
            res = amountGenerator(Integer.parseInt(cabbean.getKmsUsed()),cabbean.getCabType());
            
        }
        return("Total Amount: " + res[1] + ", Receipt ID: " + res[0]);
    }

    public static int[] amountGenerator(int kmsUsed, String cabType){
        int[] result = new int[2];
        Random rand = new Random();
        result[0] = rand.nextInt(99999) + 10000;
        if(cabType.equalsIgnoreCase("Tata indica")){
            result[1] = 12 * kmsUsed;
        }
        else if(cabType.equalsIgnoreCase("tata indigo")){
            result[1] = 10 * kmsUsed;
        }
        else if(cabType.equalsIgnoreCase("bmw")){
            result[1] = 45 * kmsUsed;
        }
        else if(cabType.equalsIgnoreCase("logan")){
            result[1] = 31 * kmsUsed;
        }
        return result;
    }
    
}
